package Cofre;

import java.util.ArrayList;
import java.util.List;

public class Principal {

	public static void main(String[] args) {
  
		Menu menu = new Menu();
		menu.Mostrarmenu1();
		
		
	}

}
