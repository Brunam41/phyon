package Cofre;

public class Real extends Moeda {
	//a classe se extende a classe moeda, a qual é filha
	
	public Real(double valorI) {
		this.valor = valorI;
	}

	@Override
	public void info() {
		System.out.println("Real = R$ " + valor );
		
	}

	@Override
	public double converter() {
		return this.valor;
	}
	
	@Override
	public boolean equals(Object objeto) {
		return false;
	
	
		
	}

}
