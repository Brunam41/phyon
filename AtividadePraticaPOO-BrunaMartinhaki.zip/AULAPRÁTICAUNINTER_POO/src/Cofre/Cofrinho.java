package Cofre;

import java.util.ArrayList;

public class Cofrinho {
	
	private ArrayList<Moeda> listagemMoeda;
	
	public Cofrinho() {
		this.listagemMoeda = new ArrayList<>(); 	
	}

	public void adicionar(Moeda moeda) {
		this.listagemMoeda.add(moeda);
	}
	

	public void listarMoedas() {
		
		if (this.listagemMoeda.isEmpty()) {
			System.out.println("O cofrinho está vazio!");
		return;
		}
	
		for (Moeda moeda : this.listagemMoeda) {
		moeda.info();
	}
		
		
		
		}

	public double valortotalconvertido() {
		
		if (this.listagemMoeda.isEmpty()) {
			return 0;
		}
		//acumulado = moedas acumuladas pelo usuário
		double acumulado = 0;
		
		for(Moeda moeda : this.listagemMoeda) {
			
			acumulado = acumulado + moeda.converter();	
		}
		
		return acumulado;
		
		}

		public boolean remover(Moeda moeda) {
			
			return this.listagemMoeda.remove(moeda);
			
		}

}
	

