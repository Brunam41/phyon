package Cofre;

import java.util.Scanner;

public class Menu {
	
	  	private Scanner entrada;
	  	private Cofrinho cofrinho;
	
		public Menu() {
		 
			entrada = new Scanner(System.in);
			cofrinho = new Cofrinho();
			// entradas no cofrinho através do Scanner
	  }
	
	public void Mostrarmenu1() {
		//menu principal que será repetido enquanto o usuário desejar interagir
		
		System.out.println("Olá bem vindo(a) ao seu novo cofrinho de moedas!");
		System.out.println("Primeiro, escolha a sua primeira ação:");
		System.out.println("                                       ");
		System.out.println("1 - Colocar dinheiro: ");
		System.out.println("2 - Retirar dinheiro: ");
		System.out.println("3 - Checar saldo: ");
		System.out.println("4 - Converter todo o saldo para Real: ");
		System.out.println("0 - Encerar");
		System.out.println("                                       ");
		
		
		String opcao = entrada.nextLine();
		
		switch (opcao) {
		// casos linkados ao menu1
			case "0": 
				System.out.println("    ");
				System.out.println("Sessão encerrada!");
				System.out.println("Até a próxima!");
					break;
			case "1":
				Mostrarsubmenudeadição();
				break;
			case "2":
				Mostrarmenudesubtração();
				break;
				
			case "3":	
				
				cofrinho.listarMoedas();
				Mostrarmenu1();
				break;					
			
			case "4":
	
				double valortotalconvertido = cofrinho.valortotalconvertido();
				String valortotalconvertidotext = String.valueOf(valortotalconvertido);
				valortotalconvertidotext = valortotalconvertidotext.replace(".", ",");
				System.out.println("O valor total convertido para Real é de : " + valortotalconvertido);
				Mostrarmenu1();
					break;
		}
	}
		private void Mostrarmenudesubtração() {
				boolean valorremover = cofrinho.remover(null);
	}

		private void Mostrarsubmenudeadição() {

			String opcao = entrada.nextLine();
			
			switch (opcao) {
			
				case "0": 
					System.out.println("    ");
					System.out.println("Sessão encerrada!");
					System.out.println("Até a próxima!");
						break;
						
				case "1":
					
					System.out.println("Muito bem, você quer colocar dinheiro");
					System.out.println("Agora informe qual a sua moeda de escolha:");
					System.out.println("                                       ");
					System.out.println("1 - Real");
					System.out.println("2 - Dólar");
					System.out.println("3 - Euro");
					System.out.println("                                       ");
					
					int escolhamoeda = entrada.nextInt();
					
					System.out.println("Digite o valor: ");
					
					String Moedavalortex = entrada.next();
					
					Moedavalortex = Moedavalortex.replace(",", ".");
					double Moedavalor = Double.valueOf(Moedavalortex);
					
					Moeda moeda = null;
					
					if (escolhamoeda == 1) {
						Real moeda1 = new Real(Moedavalor);
						cofrinho.adicionar(moeda1);
					} else if (escolhamoeda == 2) {
						Dólar moeda1 = new Dólar(Moedavalor);
						cofrinho.adicionar(moeda1);
					} else if (escolhamoeda == 3) {
						Euro moeda1 = new Euro(Moedavalor);
						cofrinho.adicionar(moeda1);
					} else {
					
					System.out.println("Não existe essa moeda!");
					Mostrarmenu1();
					
					cofrinho.remover(moeda);{
					System.out.println("Moeda removida; com sucesso!");
					} {System.out.println("Erro! Impossível remover valor, tente novamente");
					}
					
					cofrinho.adicionar(moeda);
					System.out.println("Moeda adicionada com sucesso!");
						
					}
					
					System.out.println("Moeda adicionada com sucesso!");
					System.out.println("O valor da sua moeda é de " + Moedavalortex);
					System.out.println("               ");
			
					Mostrarmenu1();
					break;
			
						//default para opções inválidas
				default:
					System.out.println("Opção Inválida!");
					Mostrarmenu1();
						break;
		}
		
		
	}
	
}
