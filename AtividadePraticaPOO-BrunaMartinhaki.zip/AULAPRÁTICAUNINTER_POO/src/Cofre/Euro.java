package Cofre;

public class Euro extends Moeda {
	//a classe se extende a classe moeda, a qual é filha
	
	public Euro (double valorI) {
		this.valor = valorI;
	}

	@Override
	public void info() {
			System.out.println("Euro = $ " + valor );
		
	}

	@Override
	public double converter() {
		return this.valor * 5.30;
	
		
	}

}
