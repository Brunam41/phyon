package Cofre;

public abstract class Moeda {
	// classe abstrata a qual aciona as funções info e converter, que são responsáveis por listar as moedas e efetuar a conversão para o Real
	
	protected double valor;
	
	public abstract void info();
	public abstract double converter();
	
	

}
