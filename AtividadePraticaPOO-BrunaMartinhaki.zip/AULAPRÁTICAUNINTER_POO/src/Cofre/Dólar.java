package Cofre;

public class Dólar extends Moeda {
	//a classe se extende a classe moeda, a qual é filha

	
	public Dólar (double valorI) {
		this.valor = valorI;
		}
	
	@Override
	public void info() {
		System.out.println("Dólar = US$ " + valor );
		
	}

	@Override
	public double converter() {
			return this.valor * 4.80;
		
	}
	
	

}
